"""Keeps a keymap file in the user's profile in step with this add-on's setting.

A keymap cannot be shipped inside a skin or a PVR client: Kodi reads them from
special://xbmc/system/keymaps/ and the two profile directories and nowhere else
(see ButtonTranslator.cpp). An add-on that writes one into the profile is the
only way to deliver one through a repository, which is what this is.
"""

import hashlib
import os

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo("name")

KEYMAP_NAME = "eon-remote.xml"
SOURCE = os.path.join(
    xbmcvfs.translatePath(ADDON.getAddonInfo("path")),
    "resources", "keymaps", KEYMAP_NAME,
)
TARGET_DIR = xbmcvfs.translatePath("special://profile/keymaps/")
TARGET = os.path.join(TARGET_DIR, KEYMAP_NAME)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("{}: {}".format(ADDON_NAME, message), level)


def digest(path):
    try:
        with open(path, "rb") as handle:
            return hashlib.md5(handle.read()).hexdigest()
    except OSError:
        return None


def install():
    """Returns True when the profile's copy changed and needs a reload."""
    wanted = digest(SOURCE)
    if wanted is None:
        log("Cannot read the bundled keymap at {}".format(SOURCE), xbmc.LOGERROR)
        return False

    if digest(TARGET) == wanted:
        return False

    if not xbmcvfs.exists(TARGET_DIR):
        xbmcvfs.mkdirs(TARGET_DIR)

    # Read and write rather than copy: the source sits inside the add-on, which
    # on Android is not necessarily on the same filesystem as the profile.
    with open(SOURCE, "rb") as src, open(TARGET, "wb") as dst:
        dst.write(src.read())

    log("Installed {}".format(TARGET))
    return True


def remove():
    """Returns True when the profile's copy was there and has now gone."""
    if not os.path.exists(TARGET):
        return False

    try:
        os.remove(TARGET)
    except OSError as error:
        log("Could not remove {}: {}".format(TARGET, error), xbmc.LOGERROR)
        return False

    log("Removed {}".format(TARGET))
    return True


def apply_setting():
    changed = install() if ADDON.getSettingBool("enabled") else remove()
    if changed:
        # Without this the change waits for the next start, which is a
        # confusing thing to hand someone who just toggled a setting.
        xbmc.executebuiltin("Action(reloadkeymaps)")


class SettingsMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        # getSettingBool reads through to the stored value, so re-reading the
        # add-on here is not needed; the instance is already current.
        apply_setting()


if __name__ == "__main__":
    apply_setting()
    SettingsMonitor().waitForAbort()
